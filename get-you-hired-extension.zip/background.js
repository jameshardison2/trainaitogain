// Listen for messages from content scripts or popup
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    if (request.action === 'triggerSOS') {
        handleSOSRequest(request.payload, sender.tab, sendResponse);
        return true; // Keep message channel open for async response
    }
});

async function handleSOSRequest(payload, tab, sendResponse) {
    try {
        let dataUrl = "";
        
        // Only capture screen if it's a screenshot request or full SOS
        if (payload.type === 'screenshot' || payload.type === 'full_sos') {
            dataUrl = await chrome.tabs.captureVisibleTab(null, {format: 'jpeg', quality: 50});
        }
        
        let finalAffiliate = payload.referred_by || 'unknown';
        if (finalAffiliate === 'unknown' || finalAffiliate === '') {
            finalAffiliate = 'james.hardison2@gmail.com';
        }
        
        const firebaseUrl = 'https://firestore.googleapis.com/v1/projects/trainaitogain-50c19/databases/(default)/documents/sos_alerts';
        
        const firestorePayload = {
            fields: {
                timestamp: { stringValue: new Date().toISOString() },
                url: { stringValue: tab ? tab.url : 'unknown' },
                issueType: { stringValue: payload.type || 'General Error' },
                referred_by: { stringValue: finalAffiliate },
                candidate_contact: { stringValue: payload.candidate_contact || 'Not Provided' },
                status: { stringValue: 'new' }
            }
        };

        if (dataUrl) {
            firestorePayload.fields.screenshotDataUrl = { stringValue: dataUrl };
        }
        
        if (payload.textMessage) {
            firestorePayload.fields.message = { stringValue: payload.textMessage };
        }
        
        if (payload.audioData) {
            firestorePayload.fields.audioDataUrl = { stringValue: payload.audioData };
        }

        // Send to Firebase
        const response = await fetch(firebaseUrl, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(firestorePayload)
        });
        
        // Send simplified payload to Make.com Webhook
        const makePayload = {
            timestamp: new Date().toISOString(),
            url: tab ? tab.url : 'unknown',
            issueType: payload.type || 'General Error',
            referred_by: finalAffiliate,
            candidate_contact: payload.candidate_contact || 'Not Provided',
            screenshotDataUrl: dataUrl || '',
            message: payload.textMessage || '',
            audioDataUrl: payload.audioData || ''
        };
        
        fetch('https://hook.us2.make.com/pe5wis97f66dvnvgajqigkqouwmg5gzg', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(makePayload)
        }).catch(err => console.error("Make.com Webhook Error:", err));
        
        if (!response.ok) {
            throw new Error(`Firebase Error: ${response.status} ${response.statusText}`);
        }
        
        console.log("SOS Alert sent to Firebase and Make.com successfully.");
        sendResponse({ success: true });
        
    } catch (error) {
        console.error("SOS Trigger failed:", error);
        sendResponse({ success: false, error: error.message });
    }
}
