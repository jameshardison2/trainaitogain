document.addEventListener('DOMContentLoaded', () => {
    const btn = document.getElementById('btn-open-widget');
    
    btn.addEventListener('click', async () => {
        // Find the active tab on mercor
        let [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
        
        if (tab && tab.url && tab.url.includes("mercor.com")) {
            // Send a message to the content script in this tab to open the widget
            chrome.tabs.sendMessage(tab.id, { action: 'openWidget' });
            // Close the popup window automatically
            window.close();
        } else {
            alert("Please navigate to the Mercor Candidate Portal to use the Lifeline.");
        }
    });
});
