let isEnabled = true;

if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', initLifeline);
} else {
    initLifeline();
}

function initLifeline() {
    // Only inject if on mercor
    if (!window.location.href.toLowerCase().includes('mercor.com')) return;
    injectLifelineWidget();
}

function injectLifelineWidget() {
    if (document.getElementById('tg-lifeline-widget')) return;
    
    const widget = document.createElement('div');
    widget.id = 'tg-lifeline-widget';
    widget.className = 'tg-lifeline-container';
    widget.innerHTML = `
        <button class="tg-lifeline-btn" id="tg-lifeline-btn">
            <span class="tg-lifeline-icon">🆘</span>
            <strong>Application Lifeline</strong>
        </button>
        
        <div class="tg-lifeline-modal tg-hidden" id="tg-lifeline-modal">
            <div class="tg-lifeline-header">
                <h3>Get Help Fast</h3>
                <button id="tg-lifeline-close">&times;</button>
            </div>
            
            <div class="tg-lifeline-body" id="tg-lifeline-step-1">
                <p>Don't let a technical issue stop you. Reach out to your referral partner directly.</p>
                
                <div style="margin-bottom: 16px;">
                    <label style="font-size: 12px; color: var(--tg-text-sec); display: block; margin-bottom: 4px;">Your Email or Phone (so we can reply)</label>
                    <input type="text" id="tg-contact-info" class="tg-chat-input" placeholder="e.g. john@email.com" autocomplete="email" style="width: 100%; box-sizing: border-box;">
                </div>
                
                <div class="tg-contact-grid">
                    <div class="tg-contact-card" id="tg-card-screenshot">
                        <div class="tg-contact-icon">📸</div>
                        <div class="tg-contact-content">
                            <strong>Send Screenshot</strong>
                            <span>Show us exactly where you're stuck</span>
                        </div>
                    </div>
                    
                    <div class="tg-contact-card" id="tg-card-voice">
                        <div class="tg-contact-icon">🎙️</div>
                        <div class="tg-contact-content">
                            <strong id="tg-voice-text">Hold to Speak (Voice Note)</strong>
                            <span>Explain the issue out loud</span>
                        </div>
                    </div>
                </div>

                <div style="border-top: 1px solid var(--tg-border); margin: 16px 0;"></div>
                
                <textarea class="tg-text-area" id="tg-text-msg" placeholder="Or type a quick message..."></textarea>
                <button id="tg-btn-send-text" class="tg-btn-primary" style="padding: 10px; font-size: 13px; margin-bottom: 16px;">✉️ Send Message</button>
                
                <div class="tg-lifeline-sos-section">
                    <button id="tg-lifeline-sos-btn" class="tg-btn-danger">🚨 Request Zoom SOS Call</button>
                </div>
            </div>

            <div class="tg-lifeline-body tg-hidden" id="tg-lifeline-step-2">
                <div class="tg-sos-success">
                    <div class="tg-check">✅</div>
                    <h4>Request Sent!</h4>
                    <p>Your referral partner has been alerted and will reach out to you shortly.</p>
                    <button class="tg-btn-primary" id="tg-btn-back">Got it</button>
                </div>
            </div>
        </div>
    `;
    
    document.body.appendChild(widget);
    
    // UI Elements
    const btn = document.getElementById('tg-lifeline-btn');
    const modal = document.getElementById('tg-lifeline-modal');
    const closeBtn = document.getElementById('tg-lifeline-close');
    const step1 = document.getElementById('tg-lifeline-step-1');
    const step2 = document.getElementById('tg-lifeline-step-2');
    
    btn.addEventListener('click', () => {
        modal.classList.remove('tg-hidden');
        btn.classList.add('tg-hidden');
    });
    
    closeBtn.addEventListener('click', () => {
        modal.classList.add('tg-hidden');
        btn.classList.remove('tg-hidden');
    });
    
    document.getElementById('tg-btn-back').addEventListener('click', () => {
        step2.classList.add('tg-hidden');
        step1.classList.remove('tg-hidden');
        modal.classList.add('tg-hidden');
        btn.classList.remove('tg-hidden');
    });
    
    // Affiliate & Contact Tracking
    const urlParams = new URLSearchParams(window.location.search);
    let affiliateRef = urlParams.get('ref');
    if (affiliateRef) {
        chrome.storage.local.set({ 'affiliate_ref': affiliateRef });
    } else {
        chrome.storage.local.get(['affiliate_ref'], function(result) {
            if (result.affiliate_ref) affiliateRef = result.affiliate_ref;
        });
    }
    
    // Load saved contact info
    const contactInput = document.getElementById('tg-contact-info');
    chrome.storage.local.get(['tg_contact_info'], function(result) {
        if (result.tg_contact_info) {
            contactInput.value = result.tg_contact_info;
        }
    });

    function sendPayload(payload) {
        // Save contact info
        const contactVal = contactInput.value.trim();
        if (contactVal) {
            chrome.storage.local.set({ 'tg_contact_info': contactVal });
        }
        
        payload.referred_by = affiliateRef;
        payload.candidate_contact = contactVal;
        
        chrome.runtime.sendMessage({ action: 'triggerSOS', payload: payload }, (response) => {
            step1.classList.add('tg-hidden');
            step2.classList.remove('tg-hidden');
        });
    }

    // 1. Screenshot Action
    document.getElementById('tg-card-screenshot').addEventListener('click', () => {
        sendPayload({ type: 'screenshot' });
    });

    // 2. Text Message Action
    document.getElementById('tg-btn-send-text').addEventListener('click', () => {
        const text = document.getElementById('tg-text-msg').value.trim();
        if (text) {
            sendPayload({ type: 'text', textMessage: text });
            document.getElementById('tg-text-msg').value = '';
        }
    });

    // 3. SOS Action
    document.getElementById('tg-lifeline-sos-btn').addEventListener('click', () => {
        sendPayload({ type: 'full_sos' });
    });

    // 4. Voice Note Action (Push to talk)
    const voiceCard = document.getElementById('tg-card-voice');
    const voiceText = document.getElementById('tg-voice-text');
    let mediaRecorder;
    let audioChunks = [];

    voiceCard.addEventListener('mousedown', async () => {
        try {
            const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
            mediaRecorder = new MediaRecorder(stream);
            audioChunks = [];
            
            mediaRecorder.addEventListener('dataavailable', event => {
                audioChunks.push(event.data);
            });
            
            mediaRecorder.addEventListener('stop', () => {
                const audioBlob = new Blob(audioChunks, { type: 'audio/webm' });
                const reader = new FileReader();
                reader.readAsDataURL(audioBlob);
                reader.onloadend = () => {
                    sendPayload({ type: 'voice', audioData: reader.result });
                };
                // stop tracks
                stream.getTracks().forEach(track => track.stop());
            });
            
            mediaRecorder.start();
            voiceCard.classList.add('tg-recording');
            voiceText.innerText = "Recording... (Release to send)";
        } catch (err) {
            alert("Microphone permission denied. Please allow microphone access.");
        }
    });

    voiceCard.addEventListener('mouseup', () => {
        if (mediaRecorder && mediaRecorder.state !== 'inactive') {
            mediaRecorder.stop();
            voiceCard.classList.remove('tg-recording');
            voiceText.innerText = "Hold to Speak (Voice Note)";
        }
    });
    
    voiceCard.addEventListener('mouseleave', () => {
        if (mediaRecorder && mediaRecorder.state !== 'inactive') {
            mediaRecorder.stop();
            voiceCard.classList.remove('tg-recording');
            voiceText.innerText = "Hold to Speak (Voice Note)";
        }
    });

    // Listen for messages from popup.js to open the widget
    chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
        if (request.action === 'openWidget') {
            modal.classList.remove('tg-hidden');
            btn.classList.add('tg-hidden');
            sendResponse({ success: true });
        }
    });
}
